package AT;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cs.test.selenium.Log.logType;
import com.cs.test.selenium.Log.logUtils;


public class ActionsKeywords {
	public static WebDriver driver;
	public static WebElement element;
	
	public static void openBrowser(String fieldValue){
		
		if ("chrome".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.chrome.driver", ".\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			
		}else if("ie".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.ie.driver", ".\\lib\\IEDriverServer.exe"); 
			driver = new InternetExplorerDriver();
			
		}else if ("firefox".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.gecko.driver", ".\\lib\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		System.out.println("open "+fieldValue+" success!");
		
	}
	
	public static void openBrowser(){
		String openBrowser=fileUtils.getBrowser();
		openBrowser(openBrowser);
	}
	
	public static void openURL(String fieldValue){
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get(fieldValue);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("open "+fieldValue+" url success");
	}
	
	public static void click(String selector){
		element=elementUtils.bySelector(driver, selector);
		try {
			element.click();
			System.out.println("click  "+selector+" success");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void input(String selector,String fieldValue){

		element=elementUtils.bySelector(driver, selector);
		element.clear();
		element.sendKeys(fieldValue);
	
	}
	
	public static void closeBrowser(){
		driver.quit();
		System.out.println("close Browser");
	}
	
	public static void wait(String selector,String fieldValue){
		
		if(fieldValue=="" && selector!=""){
			WebElement waitEle;
			waitEle=elementUtils.bySelector(driver, selector);
			WebDriverWait wait=new WebDriverWait(driver,10,1);
			wait.until(ExpectedConditions.visibilityOf(waitEle));

		}else if(fieldValue!="" && selector!=""){
			WebElement waitEle;
			waitEle=elementUtils.bySelector(driver, selector);
			operateCommond.waitForValue(fieldValue,waitEle,driver);
		}else if (fieldValue!="" && selector==""){
			try {
				TimeUnit.SECONDS.sleep(Integer.parseInt(fieldValue));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("�ȴ�:"+fieldValue+"s");
		}

	}

	public static void alert(String fieldValue){
		Alert alert = operateCommond.getAlert(driver);
		if (alert == null) {
			
			try {
				throw new Exception("NoAlertPresentException: Expected alert window is not open!");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String alertText = alert.getText();
		System.out.println("Alert text: " + alertText);
		
		if (StringUtils.isEmpty(fieldValue)) {
			alert.accept();
		} else if ("ok".equalsIgnoreCase(fieldValue)) {
			alert.accept();
		} else if ("cancel".equalsIgnoreCase(fieldValue)) {
			alert.dismiss();
		} else {
			alert.sendKeys(fieldValue);
			alert.accept();
		}
		
	}
	
	public static void check(String selector){
		element=elementUtils.bySelector(driver, selector);
		String type = element.getAttribute("type");
		if(type == null) type = "";
		type = type.toLowerCase();
		if(type.equals("checkbox") || type.equals("radio")){
			if(!element.isSelected()){
				element.click();

			}
		}else{
				try {
					throw new Exception("Command[check] is only suitable for CHECKBOX OR RADIO BUTTON. Please check type of target:"+ selector);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public static void uncheck(String selector){
		WebElement element = elementUtils.bySelector(driver, selector);
		String type = element.getAttribute("type");
		if(type == null) type = "";
		type = type.toLowerCase();
		if(type.equals("checkbox")){
			if(element.isSelected()){
				//long timeoutSeconds = ENV.getPageloadTimeout();
				long timeoutSeconds = 10;
				new WebDriverWait(driver, timeoutSeconds).until(ExpectedConditions.elementToBeClickable(element));
				element.click();
			}
		}else{
				try {
					throw new Exception("Command[uncheck] is only suitable for CHECKBOX OR RADIO BUTTON. Please check type of target:"+ selector);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public static void inFrame(String selector){
		driver.switchTo().defaultContent();
		String[] frames = selector.split(",");
		for(String frame: frames){
			String frameID = frame.trim();
			driver.switchTo().frame(frameID);
		}
	}
	
	public static void outFrame(String selector){
		driver.switchTo().defaultContent();
	}
	
	public static void saveData(String selector,String fieldValue){
		element=elementUtils.bySelector(driver, selector);
		String elementValue = elementUtils.getElementValue(element);
		operateCommond.saveGlobalData(fieldValue, elementValue);
		operateCommond.saveParameter(fieldValue,elementValue);
	}
	
	public static void loadData(String selector,String fieldValue){
		element=elementUtils.bySelector(driver, selector);
		operateCommond.loadParameter(fieldValue, element);
	}
	
	public static void savescreen(String fieldValue){
		
		String filePath = pathUtils.getResultPicPath()+operateCommond.getCurrentDate()+"\\";
		if(driver == null) return;
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(filePath+fieldValue));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void doubleClick(String selector){
		element=elementUtils.bySelector(driver, selector);
		Actions action = new Actions(driver);
		action.doubleClick(element).perform();
		System.out.println("double click" +selector+" success");

	} 
	
	
	public static void dnd(String selector){
		
		String[] str=selector.split(";");
		String x="";
		String y="";
		
		if(str.length>2){
			x=(str[2].split("="))[1];
			y=(str[3].split("="))[1];
		}
		WebElement weSource = elementUtils.bySelector(driver, (str[0].split("="))[1]);;
		WebElement weTarget = elementUtils.bySelector(driver, (str[1].split("="))[1]);
		Actions action = new Actions(driver);
		if(StringUtils.isEmpty(x)){
			action.clickAndHold(weSource).moveToElement(weTarget).release(weTarget).perform();
		}else{
			int xOffset = Integer.valueOf(x).intValue();
			int yOffset = Integer.valueOf(y).intValue();
			action.clickAndHold(weSource).perform();

			action.moveToElement(weTarget, xOffset, yOffset).perform();

			action.release(weTarget).perform();

		}
	}
	
	//operate explorer back/forward/refresh
	public static void operateBrowser(String fieldValue){
		if((fieldValue.toLowerCase()).equals("back")){
			driver.navigate().back();
			
		}else if((fieldValue.toLowerCase()).equals("forward")){
			driver.navigate().forward();
		}else if((fieldValue.toLowerCase()).equals("refresh")){
			driver.navigate().refresh();
		}
		
	}
	
	//scroll bar
	/**
	 * 
	 * @param selector:滚动到特定元素的位置
	 * @param fieldValue：自定义滚动到某个位置
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public static void scrollBar(String selector,String fieldValue) {
		element=elementUtils.bySelector(driver, selector);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		if(fieldValue!=""){
			//Scroll to a location
			js.executeScript("window.scrollBy(0, fieldValue)");
		}else{
			//Scroll to the element
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			//Scroll to a bottom
			//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}
		
	}

	//copy file
	public static void copyFile(String selector){
		String srcfilepath=(selector.split(";")[0]).split("=")[1];
		String desfilepath=(selector.split(";")[1]).split("=")[1];
		String fileName=(selector.split(";")[2]).split("=")[1];
		File srcfile= new File(srcfilepath+fileName);
		File desfile= new File(desfilepath+fileName);

		if(srcfile.exists()){
		
			   if(!desfile.exists()){ //Determine whether the target file exists
				   
				   try {
					FileUtils.copyFile(srcfile, desfile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}    
				    }else{
				    	if(!fileUtils.getFileMD5(srcfilepath+fileName).equals(fileUtils.getFileMD5(desfilepath+fileName))){ 
				    		try {
								FileUtils.copyFile(srcfile, desfile);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}    
			    	  }
				    }
		}else{
			
			logUtils.Output(logType.LogTypeName.ERROR,"copy file does not exist: " + srcfile.toString());
			try {
				throw new Exception("copy file does not exist: " + srcfile.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}
	
	public static void selectItem(String selector,String fieldValue){
		element=elementUtils.bySelector(driver, selector);
		Select select = new Select(element);
		int idx = fieldValue.indexOf(",");
	    if(idx<0){
	    	operateCommond.listSelect(select,fieldValue);
	    }else{
	    	select.deselectAll();
	    	String[] values = fieldValue.split(",");
	    	for(int i=0,size=values.length;i<size;i++){
	    		operateCommond.listSelect(select,values[i].trim());
	    	}
	    }
		
	}
	
	public static void checkPoint(String selector,String fieldValue){
		String elementValue=null;
		Boolean chkFlag=null;
		element=elementUtils.bySelector(driver, selector);
		if(fieldValue.contains("value")){
			elementValue=elementUtils.getElementValue(element);
		}else if(fieldValue.contains("text")){
			elementValue=element.getText();
		}
		
		fieldValue=fieldValue.split("=")[1];
		
		if(fieldValue.startsWith("_PARA_")){
			fieldValue=operateCommond.loadGlobalData(fieldValue);
		}
		
		if(fieldValue.contains("*=")){
			if(elementValue.contains(fieldValue)){
				chkFlag=true;
			}else{
				chkFlag=false;
			}
		}else{
			if(fieldValue.equals(elementValue)){
				chkFlag=true;
			}else{
				chkFlag=false;
			}
		}
		
//		if(chkFlag){
//			logUtils.Output(logType.LogTypeName.INFO,"check value is [" + fieldValue+"], and result is ["+elementValue+"]----check ok!");
//			System.out.println("check value is [" + fieldValue+"], and result is ["+elementValue+"]----check ok!");
//		}else{
//			logUtils.Output(logType.LogTypeName.ERROR,"check value is [" + fieldValue+"], and result is ["+elementValue+"]----check not ok!");
//			System.out.println("check value is [" + fieldValue+"], and result is ["+elementValue+"]----check not ok!");
//			reportUtils.writeResult(AutoTestStep.testScenior, "FAIL");
//		}
	}
	
}
