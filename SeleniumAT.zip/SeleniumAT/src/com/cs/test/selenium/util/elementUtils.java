package com.cs.test.selenium.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cs.test.selenium.Log.logType;
import com.cs.test.selenium.Log.logUtils;

public class elementUtils {
	
	
	public static WebElement bySelector(WebDriver driver,String selector){
		
		boolean findElement;
		WebElement ele = null;
		
		By locator=getLocator(selector);
		
		findElement=isElementPresent(driver,locator);
		
		if(findElement==true){
			ele=driver.findElement(locator);
		}else{
		}
		
		return ele;

	}

	public static By getLocator(String target){
		By locator = null;
		int index = target.indexOf("=");
		  
		String key = target.substring(0, index).toLowerCase();
		String path = target.substring(index+1);
		if(key.equals("id")){
			locator = By.id(path);
		}else if(key.equals("name")){
			locator = By.name(path);
		}else if(key.equals("xpath")){
			locator = By.xpath(path);
		}else if(key.equals("css")){
			locator = By.cssSelector(path);
		}else if(key.equals("link")){
			locator = By.linkText(path);
		}
		return locator;
	}
	
	
	public static boolean isElementPresent(WebDriver driver,By by){
	      try{
	    	  WebDriverWait wait=new WebDriverWait(driver,10,1);
	  		  wait.until(ExpectedConditions.visibilityOf(driver.findElement(by)));
	          driver.findElement(by);
	          return true;
	      }catch(Exception e){
	    	  
	    	  logUtils.Output(logType.LogTypeName.ERROR,"can't find this element!"+"--"+ by.toString());
	    	  
	          return false;
	          
	      }
	  }
	
	//get element valueֵ
	public static String getElementValue(WebElement element){
		String tagName = element.getTagName();
		String value = "";
		if("input".equalsIgnoreCase(tagName)){
			value = element.getAttribute("value");
		}else if("textarea".equalsIgnoreCase(tagName)){
			value = element.getText();
		}else if("select".equalsIgnoreCase(tagName)){
			Select select = new Select(element);
			List<WebElement> list = select.getAllSelectedOptions();
			StringBuffer buf = new StringBuffer();
			for(int i=0,size=list.size();i<size;i++){
				WebElement option = list.get(i);
				buf.append(option.getAttribute("value"));
				if(i<size-1) buf.append(",");
			}
			value = buf.toString();
		}else{
			//TODO: get new type element value here.
			value = element.getText();
		}
		return value;
	}


}
