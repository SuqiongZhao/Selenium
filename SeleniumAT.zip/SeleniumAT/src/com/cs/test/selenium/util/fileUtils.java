package com.cs.test.selenium.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.yaml.snakeyaml.Yaml;



public class fileUtils {

	@SuppressWarnings("resource")
	public static String getFileMD5(String filePath){  //get file's MD5 code
        File file = new File(filePath);  
        InputStream in;
        BigInteger bigInt=null;;
		try {
			in = new FileInputStream(file);
			MessageDigest digest = MessageDigest.getInstance("MD5");  ;  
	        byte buffer[] = new byte[1024];  
	        int len;  
	        while((len = in.read(buffer))!=-1){  
	            digest.update(buffer, 0, len);  
	        }  
	        bigInt = new BigInteger(1, digest.digest());   
	       
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 return bigInt.toString(16);  
    }
	
	
	public static boolean fileExists(String path){ //Determine whether a file exists

		File file = new File(path);
		return file.exists();
	}
	
	
	public static String getBrowser(){
		String configPath=pathUtils.getConfigPath("conifg.xlsx");
		XSSFWorkbook configWB=ExcelUtils.getExcelFile(configPath);
		XSSFSheet caseSH=ExcelUtils.getSheet(configWB, "ENV_INFO");
		int caseCountRow=ExcelUtils.getSheetCountRow(caseSH);
		return ExcelUtils.getCellData(caseSH,12, 1);
		
	}
	
	//读取yaml文件
	public static Map readYaml(String yamlFile) {
		Map map=null;
		try{
			Yaml yaml = new Yaml();
	        boolean isExist = fileExists(yamlFile);
	        if (isExist) {
	            //获取yaml文件中的配置数据，然后将值转换为Map
	            map =(Map)yaml.load(new FileInputStream(yamlFile));
	            //System.out.println(map);

	        }
		}catch (Exception e){
			e.printStackTrace();
		}
		
		return map;
		
	}
	

	
	public static void main(String[] args){
		//"C:/Users/suqiongzhao/workspace/KTEC20190101/dataEngine/FiledSelector.yml"
		String yamlFile=pathUtils.getConfigPath("FiledSelector.yml");
		readYaml(yamlFile);
	}
	
	
}
