package com.cs.test.selenium.util;


import org.openqa.selenium.WebDriver;



public class ENV {
	private static WebDriver currentDriver;

	
	public static WebDriver getDriver() {
		return currentDriver;
	}
	
	public static void setCurrentDriver(WebDriver driver) throws Exception{

		currentDriver = driver;

	}
	
	
}
