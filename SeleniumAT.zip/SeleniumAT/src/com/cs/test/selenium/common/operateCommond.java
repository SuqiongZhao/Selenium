package com.cs.test.selenium.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;















import com.cs.test.selenium.Log.logType;
import com.cs.test.selenium.Log.logUtils;
import com.cs.test.selenium.util.ExcelUtils;
import com.cs.test.selenium.util.elementUtils;
import com.cs.test.selenium.util.pathUtils;
import com.cs.test.selenium.util.reportUtils;


public class operateCommond {
	public static FileOutputStream os=null;
	public static File file=null;
	public static Map<String, String> globalStore;
	
	static{
		globalStore = new HashMap();
	}
	
	//AutoTest initializa
	public static void initializaAT(){
		clearParameter();
		initFolder();
		logUtils.createLogs();
		reportUtils.createReportFile();
	}
	
	//create folder
	public static void initFolder(){
		String currentDate=getCurrentDate();
		//createFolder(pathUtils.getLogPath()+currentDate);
		//createFolder(pathUtils.getReportPath()+currentDate);
		createFolder(pathUtils.getResultPicPath()+currentDate);
	}
	
	public static void createFolder(String folderPath){
		file=new File(folderPath);
		if(!file.exists()){
			file.mkdirs();
		}else{
			String[] tempList = file.list();
			File temp = null;
			for (int i = 0; i < tempList.length; i++) {
		          if (folderPath.endsWith(File.separator)) {
		             temp = new File(folderPath + tempList[i]);
		          } else {
		              temp = new File(folderPath + File.separator + tempList[i]);
		          }
		          if (temp.isFile()) {
		             temp.delete();
		          }
		       }
		}
	}
	
	//get current date
	public static String getCurrentDate(){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String currentDate=df.format(new Date());
		return currentDate;
		
	}
	
	public static void waitForValue(String fieldValue,WebElement element,WebDriver driver) {
		ExpectedCondition<Boolean> elementCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				try {
					String elementValue = elementUtils.getElementValue(element);
					if(!fieldValue.equals(elementValue)){
						System.out.println("The wait value is not found and Wait element value is:" + elementValue);
						return false;
					}else{
						System.out.println("The wait value is found and Wait element value is:" + elementValue);
						return (fieldValue.equals(elementValue));
					}
				} catch (Exception e) {
					
					return false;
				}
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		// wait for page complete
		wait.until(elementCondition);
	}
	
	public static Alert getAlert(WebDriver driver) {
		long iStart = System.currentTimeMillis();
		long iEnd = iStart + 5000;
		Alert alert = null;
		while (alert == null && System.currentTimeMillis() <= iEnd) {
			try {
				alert = driver.switchTo().alert();
			} catch (Exception e) {
				try {
					Thread.sleep(100);
				} catch (Exception e1) {

				}
			}
		}
		return alert;
	}
	
	public static void saveParameter(String paraName, String paraValue){
		
		String paraPath=pathUtils.getConfigPath("parameter.xlsx");
		XSSFWorkbook paraWB=ExcelUtils.getExcelFile(paraPath);
		XSSFSheet paraSH=ExcelUtils.getSheet(paraWB, "PARA_LIST");
		int indexRow=paraSH.getLastRowNum();
		XSSFRow row = paraSH.createRow(indexRow + 1);
		row.createCell(0).setCellValue(paraName);
		row.createCell(1).setCellValue(paraValue);
		try {
			os = new FileOutputStream(paraPath);
			paraWB.write(os);
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void clearParameter(){
		
		String paraPath=pathUtils.getConfigPath("parameter.xlsx");
		XSSFWorkbook paraWB=ExcelUtils.getExcelFile(paraPath);
		XSSFSheet paraSH=ExcelUtils.getSheet(paraWB, "PARA_LIST");
		int lastRow=paraSH.getLastRowNum();
		if(lastRow>0){
			for(int i=1;i<=lastRow;i++){
				XSSFRow row = paraSH.getRow(i);
				paraSH.removeRow(row);
			}
			
			try {
				os = new FileOutputStream(paraPath);
				paraWB.write(os);
				os.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}


	public static void loadParameter(String fieldValue, WebElement element){
		// TODO Auto-generated method stub
		String paraPath=pathUtils.getConfigPath("parameter.xlsx");
		XSSFWorkbook paraWB=ExcelUtils.getExcelFile(paraPath);
		XSSFSheet paraSH=ExcelUtils.getSheet(paraWB, "PARA_LIST");
		int lastRow=paraSH.getLastRowNum();
		if(lastRow>0){
			for(int i=1;i<=lastRow;i++){
				String paraName=paraSH.getRow(i).getCell(0).getStringCellValue();
				if(paraName.equals(fieldValue)){
					String paraValue=paraSH.getRow(i).getCell(1).getStringCellValue();
					element.clear();
					element.sendKeys(paraValue);
					break;
				}
				
			}
		}
	}
	
	public static void listSelect( Select select, String value){
		if(value == null) return;
		if(value.startsWith("text=")){
			select.selectByVisibleText(value.substring(5).trim());
		}else if(value.startsWith("value=")){
			select.selectByValue(value.substring(6).trim());
		}else{
			long timeout = 5000;
			long end = System.currentTimeMillis() + timeout;
			boolean selected = false;
			while(System.currentTimeMillis() < end){
				int selectIndex = selectByTextOrValue(select, value);
				if(selectIndex>=0){
					return;
				}
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			logUtils.Output(logType.LogTypeName.ERROR,"Can not find SELECT value:"+value);
			try {
				throw new Exception("Can not find SELECT value:"+value);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private static int selectByTextOrValue(Select select, String value){
		long start = System.currentTimeMillis();
		List elements = select.getOptions();
		for(int i=0,size=elements.size();i<size;i++){
			WebElement option = (WebElement)elements.get(i);
			if(value.equals(option.getAttribute("value")) || value.equals(option.getText())){
				option.click();
				return i;
			}
		}
		return -1;
	}
	
	public static void saveGlobalData(String key, String value){
		globalStore.put(key, value);
	}
	
	public static String loadGlobalData(String key){
		return globalStore.get(key);
	}
	
}
