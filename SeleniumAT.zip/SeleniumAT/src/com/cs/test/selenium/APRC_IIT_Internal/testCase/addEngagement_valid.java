package com.cs.test.selenium.APRC_IIT_Internal.testCase;

import java.util.Map;

import org.apache.poi.xssf.usermodel.*;

import com.cs.test.selenium.Tool.DBContainer;
import com.cs.test.selenium.command.*;
import com.cs.test.selenium.util.*;

public class addEngagement_valid {
	public static String yamlFile=pathUtils.getConfigPath("TestCaseInfo_PRCInternal.yml");
	public static Map map=fileUtils.readYaml(yamlFile);
	public static Map<String, String> loginInfoMap=(Map) map.get("loginInfo");
	public static Map<String, String> mainPageMap=(Map) map.get("MainPage");
	public static Map<String, String> engagementMap=(Map) map.get("AddEngagement");
	public static Map<String, String> dbInfo=(Map) map.get("DBInfo");
	

	private static void login(){
		CmdOpenBrowser.run(loginInfoMap.get("browser"));
		CmdOpenURL.run(loginInfoMap.get("url"));
		CmdWait.run(1);
		CmdInput.run(mainPageMap.get("email"), loginInfoMap.get("username"));
		CmdClick.run(mainPageMap.get("loginEle"));
		CmdWait.run(3);
	}
	
	private static void Engagement(){
		CmdClick.run(mainPageMap.get("my_engagement"));
		
	}
	
	private static void close(){
		CmdCloseBrowser.run();
	}
	
	private static void addEngagement(String entityName, String entityType,
			String groupNm, String subgroupNm, String taxPayerId, String engType,
			String serFromDate, String serEndDate, String partner, String manager,
			String member, String isLock) {
		
		CmdClick.run(engagementMap.get("create_new_client"));
		CmdWait.run(engagementMap.get("entity_name"));
		
		CmdInput.run(engagementMap.get("entity_name"), entityName);
		
		CmdClick.run(engagementMap.get("entity_type"));
		CmdClick.run((engagementMap.get("entity_type_value")).replace(
				"&param$", entityType));
		
		CmdInput.run(engagementMap.get("tax_payer_id"), taxPayerId);
		CmdScrollBar.run(engagementMap.get("tax_payer_id"));
		
		/*Operate Date field_S*/
		CmdCalendar.run(engagementMap.get("service_from_date"), serFromDate);
		CmdCalendar.run(engagementMap.get("service_end_date"), serEndDate);
		CmdWait.run(1);
		CmdClick.run(engagementMap.get("entity_name"));
		CmdClick.run(engagementMap.get("blank_space"));
		CmdClick.run(engagementMap.get("service_end_date").split("\\$")[0]);
		CmdWait.run(1);
		CmdClick.run(engagementMap.get("blank_space"));
		CmdWait.run(1);
		CmdClick.run(engagementMap.get("blank_space"));
		/*Operate Date field_E*/
		
		CmdClick.run(engagementMap.get("engagement_type"));
		CmdClick.run((engagementMap.get("engagement_type_value")).replace(
				"&param$", engType));
		
		/*
		 * Step1: Determine whether the group exists or not; 
		 * step2: if not exists,then add this group
		 * step3: select group
		 */
		String sqlStr="select count(*) from prc_iit_group where group_name='"+groupNm+"' and parent_group_id is null;";
		int count=DBContainer.executeSQL(dbInfo, sqlStr);
		CmdMouseMove.run(engagementMap.get("group_name"));
		if(count==0){
			CmdInput.run(engagementMap.get("group_name_input"), groupNm);
			CmdClick.run(engagementMap.get("group_name_add"));
		}
		CmdClick.run((engagementMap.get("group_name_select")).replace("&param$", groupNm));
		
		sqlStr="select count(*) from prc_iit_group where group_name='"+subgroupNm+"' and parent_group_id is not null;";
		count=DBContainer.executeSQL(dbInfo, sqlStr);
		CmdMouseMove.run(engagementMap.get("subgroup_name"));
		if(count==0){
			CmdInput.run(engagementMap.get("subgroup_name_input"), subgroupNm);
			CmdClick.run(engagementMap.get("subgroup_name_add"));
		}
		CmdClick.run((engagementMap.get("subgroup_name_select")).replace("&param$", subgroupNm));
		
		//select partner
		CmdInput.run(engagementMap.get("partner"), partner);
		CmdClick.run(engagementMap.get("partner"));
		CmdWait.run((engagementMap.get("partner_select")).replace("&param$", partner));
		CmdClick.run((engagementMap.get("partner_select")).replace("&param$", partner));
		
		//select lock up holder
		CmdInput.run(engagementMap.get("manager"), manager);
		CmdClick.run(engagementMap.get("manager"));
		CmdWait.run((engagementMap.get("manager_select")).replace("&param$", manager));
		CmdClick.run((engagementMap.get("manager_select")).replace("&param$", manager));
		
		
		//选择team member
		CmdInput.run(engagementMap.get("member"), member);
		CmdClick.run(engagementMap.get("member"));
		CmdWait.run((engagementMap.get("member_select")).replace("&param$", member));
		CmdClick.run((engagementMap.get("member_select")).replace("&param$", member));
		CmdClick.run(engagementMap.get("member_add"));
		
		if("yes".equalsIgnoreCase(isLock)){
			CmdClick.run(engagementMap.get("lock_y"));
		}else{
			CmdClick.run(engagementMap.get("lock_n"));
		}
		
		CmdClick.run(engagementMap.get("save"));

	}
	
	public static void main(String[] args) {
		
		String entityName = null, entityType = null, groupNm = null, subgroupNm = null, taxPayerId = null;
		String engType = null, serFromDate = null, serEndDate = null, partner = null, manager = null;
		String member = null, isLock = null;
		
		String testDatePath = pathUtils.getRootPath()
				+ "/TestData/Engagement_PRCInternal/Engagement.xlsx";
		XSSFWorkbook workbook = ExcelUtils.getExcelFile(testDatePath);
		XSSFSheet worksheet = ExcelUtils.getSheet(workbook, "sheet1");

		int totalRow = ExcelUtils.getSheetCountRow(worksheet);
		
		login();
		Engagement();
		

		for (int i = 1; i <= totalRow; i++) {
			entityName = ExcelUtils.getCellData(worksheet, i, 1);
			entityType = ExcelUtils.getCellData(worksheet, i, 2);
			groupNm = ExcelUtils.getCellData(worksheet, i, 3);
			subgroupNm = ExcelUtils.getCellData(worksheet, i, 4);
			taxPayerId = ExcelUtils.getCellData(worksheet, i, 5);
			engType = ExcelUtils.getCellData(worksheet, i, 6);
			serFromDate = ExcelUtils.getCellData(worksheet, i, 7);
			serEndDate = ExcelUtils.getCellData(worksheet, i, 8);
			partner = ExcelUtils.getCellData(worksheet, i, 9);
			manager = ExcelUtils.getCellData(worksheet, i, 10);
			member = ExcelUtils.getCellData(worksheet, i, 11);
			isLock = ExcelUtils.getCellData(worksheet, i, 12);
			
			addEngagement(entityName, entityType, groupNm, subgroupNm, taxPayerId,
					engType, serFromDate, serEndDate, partner, manager, member,
					isLock);
		}
		
		close();


	}

}
