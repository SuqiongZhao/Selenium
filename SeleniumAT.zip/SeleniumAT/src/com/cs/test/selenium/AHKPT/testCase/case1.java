package com.cs.test.selenium.AHKPT.testCase;

import java.util.Map;

import com.cs.test.selenium.command.*;
import com.cs.test.selenium.util.*;

public class case1 {
	public static String yamlFile=pathUtils.getConfigPath("FiledSelector.yml");
	public static Map map=fileUtils.readYaml(yamlFile);
	public static Map<String, String> loginInfoMap=(Map) map.get("loginInfo");
	public static Map<String, String> mainPageMap=(Map) map.get("MainPage");
	public static Map<String, String> engagementMap=(Map) map.get("Engagement");
	
	
	
	private static void login(){
		CmdOpenBrowser.run("Chrome");
		CmdOpenURL.run("http://10.119.169.22/index.html#/temp");
		CmdWait.run(1);
		CmdInput.run("xpath=//input[@type='email']", "suqiong.zhao@kpmg.com");
		CmdClick.run("xpath=//span[text()='进入系统']");
		CmdWait.run(5);
	}
	
	private static void login1(){
		CmdOpenBrowser.run(loginInfoMap.get("browser"));
		CmdOpenURL.run(loginInfoMap.get("url"));
		CmdWait.run(1);
		CmdInput.run(mainPageMap.get("email"), loginInfoMap.get("username"));
		CmdClick.run(mainPageMap.get("loginEle"));
		CmdWait.run(5);
	}
	
	private static void Engagement(){
		CmdClick.run("xpath=//span[text()='My Engagements']");
		CmdClick.run("xpath=//div[@class='ivu-form-item-content']//span[text()='New client']");
	}
	
	private static void addEngagement(String param1,String param2){
		String path1_0="xpath=//span[text()='please select']";
		String path1_1="xpath=//li[text()='"+param1+"']";
		String path2="xpath=//*[@id='app']/div/div[2]/div/section/form/div[1]/div[1]/div[2]/div[1]/div/div[1]/input";

		CmdClick.run(path1_0);
		CmdClick.run(path1_1);
		CmdInput.run(path2, param2);
		
	}
	
	public static void main(String[] args){
		login1();
//		login();
//		Engagement();
//		
//		addEngagement("Objection","12");
	}

}
