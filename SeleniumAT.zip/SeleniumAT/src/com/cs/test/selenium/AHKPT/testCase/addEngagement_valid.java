package com.cs.test.selenium.AHKPT.testCase;

import java.util.Map;

import com.cs.test.selenium.command.*;
import com.cs.test.selenium.util.*;

public class addEngagement_valid {
	public static String yamlFile=pathUtils.getConfigPath("TestCaseInfo_hkpt.yml");
	public static Map map=fileUtils.readYaml(yamlFile);
	public static Map<String, String> loginInfoMap=(Map) map.get("loginInfo");
	public static Map<String, String> mainPageMap=(Map) map.get("MainPage");
	public static Map<String, String> engagementMap=(Map) map.get("Engagement");
	
	
	private static void login(){
		CmdOpenBrowser.run(loginInfoMap.get("browser"));
		CmdOpenURL.run(loginInfoMap.get("url"));
		CmdWait.run(1);
		CmdInput.run(mainPageMap.get("email"), loginInfoMap.get("username"));
		CmdClick.run(mainPageMap.get("loginEle"));
		CmdWait.run(5);
	}
	
	private static void Engagement(){
		CmdClick.run(mainPageMap.get("my_engagement"));
		CmdClick.run(engagementMap.get("create_new_client"));
	}
	
	private static void addEngagement(String param1,String param2){

		CmdClick.run(engagementMap.get("engagement_type"));
		CmdClick.run((engagementMap.get("engagement_type_value")).replace("&param$", param1));
		CmdInput.run(engagementMap.get("irdNum_two"), param2);
		
	}
	
	public static void main(String[] args){
		login();
		Engagement();
		addEngagement("Objection","12");
	}

}
