package com.cs.test.selenium.command;

import java.io.IOException;

import org.openqa.selenium.*;

import com.cs.test.selenium.util.ENV;
import com.cs.test.selenium.util.elementUtils;


public class CmdScrollBar {
	
	/**
	 * 
	 * @param selector:滚动到特定元素的位置
	 * @param fieldValue：自定义滚动到某个位置
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public static void run(String selector,String fieldValue) {
		WebDriver driver = ENV.getDriver();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		if(fieldValue!=null && selector==null){
			//Scroll to a location
			js.executeScript("window.scrollBy(0, "+Integer.valueOf(fieldValue)+")");
		}else if(fieldValue==null && selector!=null){
			//Scroll to the element
			WebElement element=elementUtils.bySelector(driver, selector);
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			//Scroll to a bottom
			//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}
		
	}
	
	public static void run(String fieldValue){
		//run(null,fieldValue);
		run(fieldValue,null);
		
	}

}
