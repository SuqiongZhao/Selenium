package com.cs.test.selenium.command;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.cs.test.selenium.util.ENV;

public class CmdKeyDown {
	
	public static void run(String selector,String fieldValue){
		
		WebDriver driver = ENV.getDriver();
		Actions actions = new Actions(driver);
		
		switch(fieldValue){
		
		case "ENTER":
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.ENTER).keyUp(Keys.CONTROL).perform();
		}

	}
	
	public static void run(String fieldValue){
		run(null,fieldValue);
		
	}

}
