package com.cs.test.selenium.command;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.cs.test.selenium.util.ENV;

public class CmdOpenURL {
	
//	public CmdOpenURL() {
//		super();
//	}
	
	public static void run(String fieldSelector,String fieldValue){
		WebDriver driver = ENV.getDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get(fieldValue);
		

		System.out.println("open "+fieldValue+" url success");
	}
	
	public static void run(String fieldValue){
		run(null,fieldValue);
	}

}
