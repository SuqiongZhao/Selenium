package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;

import com.cs.test.selenium.util.ENV;

public interface CmdOperateBrowser {
	
	public static void run(String selector,String fieldValue){
		WebDriver driver = ENV.getDriver();
		if((fieldValue.toLowerCase()).equals("back")){
			driver.navigate().back();
			
		}else if((fieldValue.toLowerCase()).equals("forward")){
			driver.navigate().forward();
		}else if((fieldValue.toLowerCase()).equals("refresh")){
			driver.navigate().refresh();
		}
		
		CmdWait.run(2);
	}
	
	public static void run(String fieldValue){
		run(null,fieldValue);
		
	}

}
