package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cs.test.selenium.util.ENV;
import com.cs.test.selenium.util.elementUtils;

public class CmdMouseMove {
	
	public static void run(String selector,String fieldValue){
		WebDriver driver = ENV.getDriver();
		Actions actions = new Actions(driver);
		WebElement toElement =elementUtils.bySelector(driver, selector);
		
		actions.moveToElement(toElement).perform();;
		
	}
	
	public static void run(String selector){
		run(selector,null);
		
	}

}
