package com.cs.test.selenium.command;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;




import org.openqa.selenium.WebElement;

import com.cs.test.selenium.util.ENV;
import com.cs.test.selenium.util.elementUtils;

public class CmdCalendar {
	
	public static void run(String selector,String fieldValue){
		String jsString = null;
		int index=0;
		WebDriver driver = ENV.getDriver();
		
		if(selector.contains("$")){
			//System.out.println(selector.split("\\$")[0]);
			index=Integer.valueOf(selector.split("\\$")[1]);
			selector=selector.split("\\$")[0];
		}

		// 根据页面元素布局，编写JS代码
		if (selector.contains("xpath=")){
			
			jsString= "document.getElementsByClassName('ivu-input')["+index+"].removeAttribute('readonly')";
			
		}else if(selector.contains("id=")){
			
			jsString = "document.getElementById("+selector.split("id=")[1]+").removeAttribute('readonly')";
		
		}else if(selector.contains("name=")){

			jsString = "document.getElementByName("+selector.split("name=")[1]+").removeAttribute('readonly')";
			
		}

	    ((JavascriptExecutor)driver).executeScript(jsString);
	    CmdInput.run(selector, fieldValue);
	    
//	    //方法2
//	    WebElement dateElement =elementUtils.bySelector(driver, selector);
//
//	    ((JavascriptExecutor)driver).executeScript("arguments[0].value=arguments[1]",dateElement, fieldValue); 

	    


	}

}
