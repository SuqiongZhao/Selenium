package com.cs.test.selenium.command;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;


public class CommandFactory {

	
	private static Map<String, Class> commands;

	
	private static void CmdoperateBrowser(){
		commands = new HashMap<String, Class>();

		commands.put("openBrowser", CmdOpenBrowser.class);
		commands.put("openURL", CmdOpenURL.class);
		commands.put("input", CmdInput.class);
		commands.put("wait", CmdWait.class);
		commands.put("click", CmdClick.class);
		commands.put("calendar", CmdCalendar.class);
		commands.put("scrollBar", CmdScrollBar.class);
		commands.put("operateBrowser", CmdOperateBrowser.class);
		commands.put("doubleClick", CmdDoubleClick.class);
		commands.put("hotKey", CmdKeyDown.class);
		commands.put("closeBrowser", CmdCloseBrowser.class);
		commands.put("moveMouse", CmdMouseMove.class);
	}
	
	public static Class parseTestCommand(String cmd){

		Class cmdClass = commands.get(cmd);
		Class<?> clazz=cmdClass;
        
		System.out.println(clazz.getName());
		
		return clazz;

	}
	
	public static void main(String[] args){
		Class<?> clazz = CommandFactory.parseTestCommand("openBrowser");
		Method methodName;
		try {
			methodName=clazz.getDeclaredMethod("run");
			methodName.setAccessible(true);
			Object obj = clazz.newInstance();
	        methodName.invoke(obj,"Chrome");
		} catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	
//	public static TestCommand createCommand(String name) throws Exception{
//		TestCommand cmd = null;
//		String cmdName = name.toLowerCase();
//		
//		//find command alias first.
//		String alias = aliases.get(cmdName);
//		if(!StringUtil.isEmpty(alias)){
//			cmdName = alias.toLowerCase();
//		}
//		
//		Class cmdClass = commands.get(cmdName);
//		
//		if(cmdClass != null){
//			cmd = (TestCommand)(cmdClass.newInstance());
//			cmd.setName(name);
//		}else{
//			if(templates!=null && templates.containsKey(cmdName)){
//				cmd = new CmdTemplate();
//				cmd.setName(name);
//				((CmdTemplate)cmd).setSubCommands((List)templates.get(cmdName));
//			}else{
//				String appCmdName = ConfigReader.getAppCommandName(cmdName, false);
//				if(StringUtil.isEmpty(appCmdName)){
//					throw new Exception("Command can not be created, unknow command name:" + name);
//				}else{
//					return createCommand(appCmdName);
//				}
//			}
//		}
//		return cmd;
//	}

}
